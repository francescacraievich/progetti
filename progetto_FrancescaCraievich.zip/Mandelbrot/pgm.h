#ifndef _PGM_H
#define _PGM_H

int save_to_pgm(const char *filename, const int *iterations, int nrows, int ncols, int max_iterations);

#endif
